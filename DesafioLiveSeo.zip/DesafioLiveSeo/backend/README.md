# Projeto: Rota API

O código apresentado cria um servidor web simples usando o framework **Express.js** para atender a uma requisição de API.

1. Nas primeiras linhas de código, importamos o framework `express` para criar o servidor na variavel `app`e gerenciar as rotas. Também definimos a porta do nosso servidor para 3000.
2. Criamos um array de objetos `users`. Para um desafio pequeno, serve para simular o return, em uma aplicação real, os dados viriam de um banco de dados.
3. Definimos a rota principal da API em `app.get`. O GET é usado para solicitar dados.`'/users'`: É o *endpoint* (o caminho da URL) que aciona esta função. `(req, res) => { ... }`: É a função que será executada quando a rota for acessada. `req` contém os dados da requisição e `res` é usado para enviar a resposta.`res.json(users);`: Este comando pega o array `users`, o converte para o formato **JSON** e o envia como resposta.
4. Iniciamos o servidor em `app.listen`.