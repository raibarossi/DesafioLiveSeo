const express = require('express');
const app = express();
const port = 3000;

const users = [
  { id: 1, name: 'Ana', email: 'ana@email.com' },
  { id: 2, name: 'Pedro', email: 'pedro@email.com' }
];

app.get('/users', (req, res) => {
  res.json(users); // retorna os usuários em formato JSON
});


app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});