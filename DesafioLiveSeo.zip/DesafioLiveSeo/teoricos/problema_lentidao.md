Existem muitos fatores que podem causar problemas de carregamento em uma tela de login. 
Para diagnosticar a causa, as primeiras verificações (com o dev mode do navegador) seriam:

-> Conferir se os arquivos baixados pela página (assets) não estão sobrecarregando o sistema. Imagens, videos, fontes e outros recursos podem causar lentidão se forem muito pesados.
-> Verificar a quantidade de requisições feitas pelo sistema, pois se a página estiver tentando carregar muitos arquivos, mesmo que pequenos, a latência da rede para cada requisição se soma e causa problemas de carregamento.
-> Problemas de renderização ao carregar arquivos de css ou scripts muito robustos também podem causar lentidão em qualquer tela do navegador.

Possíveis soluções:

-> Se o problema for no front-end:
1. A otimização de recursos (assets) pode acelerar o processo de carregamento. 
2. Comprimir imagens ajuda diminuindo o tamanho dos arquivos que a página precisa baixar e destrinchar os arquivos de css e script para deixar somente o essencial também é uma solução muito efetiva.
3. Outra possibilidade é configurar o carregamento do script para que somente o essencial para a tela de login seja executado inicialmente, ao invés de todo o código.

-> Quando o problema está no back-end:

1. Otimizar a consulta no banco de dados, evitando o "SELECT *" que sempre carrega todas as colunas é uma solução muito comum quando se sabe o que será preciso carregar, utilizar um "SELECT id" ou "SELECT name", por exemplo, acelera todo o processo de carregamento.
2. Executar apenas tarefas principais para o login ao invés de realizar tarefas secundarias automáticamente, como carregar logs de acesso ou enviar mensagens de segurança para o usuário também pode agilizar o processo, embora essa solução precise ser muito bem planejada para não negligenciar etapas importantes e comprometer a segurança ou organização do sistema.
