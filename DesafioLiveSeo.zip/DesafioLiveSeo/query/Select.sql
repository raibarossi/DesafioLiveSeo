SELECT name /* Seleciona a coluna "name" de uma tabela*/
FROM users /*O nome da tabela é users*/
ORDER BY created_at DESC /*Ordena pela data de criação em ordem decrescente/*

/*A query seleciona a coluna name da tabela users ('SELECT name' e 'FROM users') 
e retorna uma lista dos nomes dos usuários em ordem decrescente 
pela data de criação ('ORDER BY created_at' e 'DESC')