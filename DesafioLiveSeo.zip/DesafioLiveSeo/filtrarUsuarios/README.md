# Projeto: Filtro de Usuários em TypeScript

Este projeto é um programa simples em typescript que recebe um array pré definido e retorna um array 
filtrado pela idade.

## Lógica:

1. Definição de Tipos: A base do projeto é a criação de um tipo `User`. Isso estabelece uma estrutura de dados, garantindo que todo objeto de usuário no sistema seja padronizado.
2. Declaração do Array: Ao declarar o array de dados, informamos que ele é uma coleção de objetos do tipo `User`. O TypeScript automaticamente valida cada objeto dentro do array para garantir que ele siga a estrutura definida.
3. Função `filtrarUsuarios`: A função utiliza uma abordagem iterativa com um loop `for...of`. No início da função, um array vazio chamado `resultado` é criado. Ele servirá para armazenar os nomes dos usuários que passarem no filtro. O loop é usado para percorrer cada um dos objetos `user` dentro do array de entrada `users`. Dentro do loop, a instrução `if (user.age > 23)` verifica se a idade do usuário atual é maior que 23. Se a condição for verdadeira, o nome do usuário (`user.name`) é adicionado ao array `resultado` através do método `.push()`. No final do loop, a função retorna o array `resultado`, que agora contém apenas os nomes dos usuários que atendem ao critério.