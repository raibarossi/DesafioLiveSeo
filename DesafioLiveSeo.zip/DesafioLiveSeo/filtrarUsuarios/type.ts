type User = {
  id: number;
  name: string;
  age: number;
};

const users: User[] = [
  { id: 1, name: "Ana", age: 25 },
  { id: 2, name: "Pedro", age: 30 },
  { id: 3, name: "Maria", age: 22 },
];

function filtrarUsuarios(users: User[]): string[] {
  let resultado: string[] = []
  for (const user of users)
    if (user.age > 23){
      resultado.push(user.name)
    }
  return resultado
}

console.log(filtrarUsuarios(users));